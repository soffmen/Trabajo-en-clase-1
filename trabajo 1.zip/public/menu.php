<ul class="nav flex-column">
            <li class="nav-item">
              <a href="prematricula.php">
                <svg class="bi"><use xlink:href="#house-fill"/></svg>
                Prematricula
              </a>
              </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="Matricula financiera.php">
                <svg class="bi"><use xlink:href="#file-earmark"/></svg>
                Matricula financiera
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="Horario.php">
                <svg class="bi"><use xlink:href="#cart"/></svg>
                Horario
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="Notas.php">
                <svg class="bi"><use xlink:href="#people"/></svg>
                Notas
              </a>
            </li>
    
              </a>
            </li>
          </ul>