<?php

$number= $_POST["valor"];
$numero =  $_POST["edad"];

if($number <=0)
{
    die("valor no valido");
}

if($numero>60)
{
  $des = $number * 0.2;
  $total = $number - $des;
  echo $total;
}else{
echo "$number";
}


?>